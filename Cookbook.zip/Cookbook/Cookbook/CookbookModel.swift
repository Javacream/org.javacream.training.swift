//
//  CookbookModel.swift
//  Cookbook
//
//  Created by Apple on 25.07.18.
//  Copyright © 2018 Javacream. All rights reserved.
//

import Foundation

class CookbookModel{
    static let instance = CookbookModel()
    
    func create(desc:String) -> Recipe{
        sleep(2)
        return Recipe(description: desc)
    }
}

struct Recipe{
    var description:String
}
