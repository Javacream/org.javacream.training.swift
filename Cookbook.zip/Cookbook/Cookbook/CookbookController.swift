//
//  CookbookController.swift
//  Cookbook
//
//  Created by Apple on 25.07.18.
//  Copyright © 2018 Javacream. All rights reserved.
//

import Foundation

class CookbookController{
    static let instance = CookbookController()
    let model = CookbookModel.instance
    
    func createRecipe(description:String, update: @escaping (Recipe) -> Void) -> Void{
    {() -> Recipe in
        self.model.create(desc: description);
        } ->- {(recipe) -> Void in
            update(recipe)
        }
        
    }
}
