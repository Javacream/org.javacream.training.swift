//
//  ViewController.swift
//  Cookbook
//
//  Created by Apple on 25.07.18.
//  Copyright © 2018 Javacream. All rights reserved.
//

import UIKit

class CookbookViewController: UIViewController {
    let controller = CookbookController.instance
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func createRecipeAction(_ sender: Any) {
        func update(_ recipe: Recipe){
            print(recipe.description)
        }
        controller.createRecipe(description: "Schweinebraten", update: update)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

