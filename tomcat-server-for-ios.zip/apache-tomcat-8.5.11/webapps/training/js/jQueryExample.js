// Eine "Ready"-Funktion
//var f = function() {
//	var cssSelector "#slot" //#slot p 
//	var jQuerySelection = jQuery(cssSelector)
//	//Selection.Command
//	jQuerySelection.html("<p>ready</p>")
//}
//jQuery(f);

jQuery(function() {
	var slot = jQuery("#slot")
	var demoButton = jQuery("#demoButton") 
	var loadButton = jQuery("#loadButton") 

	slot.html("<p>ready</p>")
	demoButton.click(function(event){
		var newP = jQuery("<p>click</p>")
		newP.click(function(event){
			newP.hide()
		})
		slot.append(newP)
	})
	
loadButton.click(function(event){
	jQuery.getJSON("http://localhost:8080/training/data/person2.json", function(result){
		alert(result.lastname)
	})
})
	
	

})