//Variablen und Literale

//message ist eine Referenz auf das String-Objekt mit dem Inhalt "Hello"
//"": String-Literal
var message = "Hello";
var number = 42;
var real_number = 4.2;
var state_var = true;
var list = [ "A", 42, false ];
var object = {
	plz : 81373,
	city : "München"
};
var reg_exp = /egal/;
// console.log("Message=" + message);
// console.log("first element in list =" + list[0]);
// console.log("plz of x as dictionary=" + object["plz"]);
// console.log("plz of x as dictionary=" + object.city);

var demo = function(listParam) {
	for (var counter = 0; counter < listParam.length; counter++) {
		// console.log(listParam[counter]);
	}
	listParam[0] = "Hugo";
	listParam = [ 1, 2 ];
	return "OK";
};

var result = demo(list);

// console.log("first element in list =" + list[0]);
// console.log("result=" + result);

var demo2 = function(f) {
	f([ "e", "gal" ]);
};

demo2(demo);

var m2 = message;
var f2 = demo;

f2(list);

//alert(message);
//alert(demo(list));
//alert(demo);
// alert(message()); //das gibt einen Fehler, message ist keine Referenz auf ein
// Funktionsobjekt!

window.lastname = "Mustermann"; 
var person = {
	lastname : "Sawitzki",
	given_names : [ "Rainer", "Ulrich" ], 
	say_hello: function(){
		return "Hello, my name is " + this.lastname;
	}
	
};
//console.log(person.say_hello());


var f = function (){
	console.log("function f, no param");
}

f = function (param1, param2){
	console.log("function f, two params, param1=" + param1 + ", param2=" + param2);
}

f = function (param){
	console.log("function f, one param, param=" + param);
	console.log(arguments.length);
	for (var counter = 0; counter < arguments.length; counter++) {
		console.log(arguments[counter]);
	}

}


f();
f("A1");
f("A2", "B2");