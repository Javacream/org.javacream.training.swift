Modernizr.load({
	test : Modernizr.geolocation,
	yep : '../js/geolocation-present.js',
	nope : '../js/geolocation-not-present.js'
})

var demo = function() {
	alert(Modernizr.geolocation);
	alert(Modernizr.svg);
};