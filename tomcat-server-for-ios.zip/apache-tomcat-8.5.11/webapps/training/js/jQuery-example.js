// Eine "Ready"-Funktion
jQuery(function() {
	jQuery("#slot").html("<p>ready</p>")
	alert("Ready")
});