//
//  PeopleModel.swift
//  org.javacream.training.swift.simpleperson
//
//  Created by Apple on 20.11.18.
//  Copyright © 2018 Javacream. All rights reserved.
//

import Foundation

class Person{
    var lastname:String = ""
    var firstname:String = ""
    var height:Int = 0
    
    init(lastname:String, firstname:String, height:Int) {
        self.lastname = lastname
        self.firstname = firstname
        self.height = height
    }
    func info() -> String{
        return "Person: lastname=\(lastname), firstname=\(height), lastname=\(height)"
    }
}

class PeopleModel{
    var people:Array<Person> = Array()
    //TODO: Params? Impl?
    func save(){
            print("save")
    }
    
    //TODO: Params? Impl?
    func dump(){
        print("dump")
    }
}
